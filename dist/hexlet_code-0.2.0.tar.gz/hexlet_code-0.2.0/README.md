### Hexlet tests and linter status:
[![Actions Status](https://github.com/2rage/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/2rage/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/3c56e6a4dd58dc81c322/maintainability)](https://codeclimate.com/github/2rage/python-project-49/maintainability)

Mind games